package com.example.PFE.repository;

import com.example.PFE.model.Utilisateur;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UtilisateurR extends JpaRepository<Utilisateur, Long> {

    // Trouver un utilisateur par email
    Optional<Utilisateur> findByEmail(String email);

    // Trouver un utilisateur par username
    Optional<Utilisateur> findByUsername(String username);

    // Vérifier l’existence d’un utilisateur par email
    boolean existsByEmail(String email);

    // Vérifier l’existence d’un utilisateur par username
    boolean existsByUsername(String username);
}
