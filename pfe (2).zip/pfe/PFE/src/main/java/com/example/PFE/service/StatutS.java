package com.example.PFE.service;

import com.example.PFE.model.Statut;
import com.example.PFE.repository.StatutR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StatutS {

    @Autowired
    private StatutR statutRepository;

    // CRUD
    public Statut createStatut(Statut statut) {
        return statutRepository.save(statut);
    }

    public Statut updateStatut(Long id, Statut statutDetails) {
        Optional<Statut> statut = statutRepository.findById(id);
        if (statut.isPresent()) {
            Statut existingStatut = statut.get();
            existingStatut.setName(statutDetails.getName());
            existingStatut.setUpdatedAt(statutDetails.getUpdatedAt()); // On suppose que l'update gère la date.
            return statutRepository.save(existingStatut);
        }
        return null; // Si l'entité n'existe pas
    }

    public List<Statut> getAllStatuts() {
        return statutRepository.findAll();
    }

    public Statut getStatutById(Long id) {
        return statutRepository.findById(id).orElse(null);
    }

    public boolean deleteStatut(Long id) {
        if (statutRepository.existsById(id)) {
            statutRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
