package com.example.PFE.controller;

import com.example.PFE.model.Rapport;
import com.example.PFE.service.RapportS;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/rapports")
public class RapportC {

    @Autowired
    private RapportS rapportService;

    // Endpoint pour obtenir tous les rapports
    @GetMapping
    public List<Rapport> getAllRapports() {
        return rapportService.getAllRapports();
    }

    // Endpoint pour obtenir un rapport par son ID
    @GetMapping("/{id}")
    public ResponseEntity<Rapport> getRapportById(@PathVariable Long id) {
        Optional<Rapport> rapport = rapportService.getRapportById(id);
        return rapport.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Endpoint pour créer un nouveau rapport
    @PostMapping
    public ResponseEntity<Rapport> createRapport(@RequestBody Rapport rapport) {
        Rapport createdRapport = rapportService.createRapport(rapport);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdRapport);
    }

    // Endpoint pour mettre à jour un rapport existant
    @PutMapping("/{id}")
    public ResponseEntity<Rapport> updateRapport(@PathVariable Long id, @RequestBody Rapport rapportDetails) {
        Rapport updatedRapport = rapportService.updateRapport(id, rapportDetails);
        return ResponseEntity.ok(updatedRapport);
    }

    // Endpoint pour supprimer un rapport
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRapport(@PathVariable Long id) {
        rapportService.deleteRapport(id);
        return ResponseEntity.noContent().build();
    }
}
