package com.example.PFE.repository;

import com.example.PFE.model.Rapport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RapportR extends JpaRepository<Rapport, Long> {
    // Méthodes personnalisées si nécessaire
    // Par exemple, recherche par titre ou auteur
}
