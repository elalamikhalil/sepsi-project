package com.example.PFE.service;

import com.example.PFE.model.Rapport;
import com.example.PFE.repository.RapportR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RapportS {

    @Autowired
    private RapportR rapportRepository;

    // Méthode pour obtenir tous les rapports
    public List<Rapport> getAllRapports() {
        return rapportRepository.findAll();
    }

    // Méthode pour obtenir un rapport par son ID
    public Optional<Rapport> getRapportById(Long id) {
        return rapportRepository.findById(id);
    }

    // Méthode pour créer un nouveau rapport
    public Rapport createRapport(Rapport rapport) {
        return rapportRepository.save(rapport);
    }

    // Méthode pour mettre à jour un rapport existant
    public Rapport updateRapport(Long id, Rapport rapportDetails) {
        Rapport rapport = rapportRepository.findById(id).orElseThrow(() -> new RuntimeException("Rapport non trouvé"));

        rapport.setTitre(rapportDetails.getTitre());
        rapport.setContenu(rapportDetails.getContenu());
        rapport.setDateCreation(rapportDetails.getDateCreation());
        rapport.setStatut(rapportDetails.getStatut());
        rapport.setAuteur(rapportDetails.getAuteur());
        rapport.setUpdatedAt(rapportDetails.getUpdatedAt());

        return rapportRepository.save(rapport);
    }

    // Méthode pour supprimer un rapport
    public void deleteRapport(Long id) {
        rapportRepository.deleteById(id);
    }
}
