package com.example.PFE.service;

import com.example.PFE.model.Utilisateur;
import com.example.PFE.repository.UtilisateurR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService implements org.springframework.security.core.userdetails.UserDetailsService {

    @Autowired
    private UtilisateurR utilisateurRepository;

    private PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    // Méthode qui charge l'utilisateur par son nom d'utilisateur
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Utilisateur utilisateur = utilisateurRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Utilisateur non trouvé"));

        // Utilisation de Spring Security UserDetails pour l'authentification
        return User.builder()
                .username(utilisateur.getUsername())
                .password(utilisateur.getPassword())  // Mot de passe crypté
                 // Ajouter les rôles si nécessaire
                .build();
    }

    // Méthode pour vérifier le mot de passe lors de l'authentification
    public boolean authenticate(String username, String password) {
        Utilisateur utilisateur = utilisateurRepository.findByUsername(username).orElse(null);
        if (utilisateur != null) {
            // Comparer le mot de passe crypté avec celui saisi par l'utilisateur
            return passwordEncoder.matches(password, utilisateur.getPassword());
        }
        return false;
    }

    // Méthode pour encoder un mot de passe avant de le stocker dans la base de données
    public String encodePassword(String password) {
        return passwordEncoder.encode(password);
    }
}
