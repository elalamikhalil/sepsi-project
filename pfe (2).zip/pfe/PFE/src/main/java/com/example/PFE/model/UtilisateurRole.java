package com.example.PFE.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Table(name = "utilisateur_roles")
public class UtilisateurRole {

    @EmbeddedId
    private UtilisateurRoleId id;

    @ManyToOne
    @MapsId("utilisateurId")
    @JoinColumn(name = "utilisateur_id")
    private Utilisateur utilisateur;

    @ManyToOne
    @MapsId("roleId")
    @JoinColumn(name = "role_id")
    private Role role;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    // Constructeurs
    public UtilisateurRole() {
    }

    public UtilisateurRole(Utilisateur utilisateur, Role role) {
        this.id = new UtilisateurRoleId(utilisateur.getId(), role.getId());
        this.utilisateur = utilisateur;
        this.role = role;
        this.createdAt = LocalDateTime.now();
    }

    // Getters et setters
    public UtilisateurRoleId getId() {
        return id;
    }

    public void setId(UtilisateurRoleId id) {
        this.id = id;
    }

    public Utilisateur getUtilisateur() {
        return utilisateur;
    }

    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    // equals et hashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UtilisateurRole that = (UtilisateurRole) o;
        return Objects.equals(utilisateur, that.utilisateur) &&
                Objects.equals(role, that.role);
    }

    @Override
    public int hashCode() {
        return Objects.hash(utilisateur, role);
    }

    // Classe Embeddable pour la clé composite
    @Embeddable
    public static class UtilisateurRoleId implements java.io.Serializable {
        private Long utilisateurId;
        private Long roleId;

        public UtilisateurRoleId() {
        }

        public UtilisateurRoleId(Long utilisateurId, Long roleId) {
            this.utilisateurId = utilisateurId;
            this.roleId = roleId;
        }

        // Getters et setters
        public Long getUtilisateurId() {
            return utilisateurId;
        }

        public void setUtilisateurId(Long utilisateurId) {
            this.utilisateurId = utilisateurId;
        }

        public Long getRoleId() {
            return roleId;
        }

        public void setRoleId(Long roleId) {
            this.roleId = roleId;
        }

        // equals et hashCode
        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            UtilisateurRoleId that = (UtilisateurRoleId) o;
            return Objects.equals(utilisateurId, that.utilisateurId) &&
                    Objects.equals(roleId, that.roleId);
        }

        @Override
        public int hashCode() {
            return Objects.hash(utilisateurId, roleId);
        }
    }
}
