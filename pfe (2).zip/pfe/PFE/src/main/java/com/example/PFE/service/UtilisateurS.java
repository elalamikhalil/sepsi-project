package com.example.PFE.service;

import com.example.PFE.model.Utilisateur;
import com.example.PFE.repository.UtilisateurR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UtilisateurS {

    @Autowired
    private UtilisateurR utilisateurR;

    // ✅ Récupérer tous les utilisateurs
    public List<Utilisateur> getAllUtilisateurs() {
        return utilisateurR.findAll();
    }

    // ✅ Récupérer un utilisateur par ID
    public Optional<Utilisateur> getUtilisateurById(Long id) {
        return utilisateurR.findById(id);
    }

    // ✅ Créer un nouvel utilisateur
    public Utilisateur createUtilisateur(Utilisateur utilisateur) {
        utilisateur.setId(null); // sécurité
        return utilisateurR.save(utilisateur);
    }

    // ✅ Mettre à jour un utilisateur existant
    public Optional<Utilisateur> updateUtilisateur(Long id, Utilisateur utilisateurDetails) {
        return utilisateurR.findById(id).map(utilisateur -> {
            utilisateur.setUsername(utilisateurDetails.getUsername());
            utilisateur.setEmail(utilisateurDetails.getEmail());
            utilisateur.setNom(utilisateurDetails.getNom());
            utilisateur.setPrenom(utilisateurDetails.getPrenom());
            utilisateur.setPassword(utilisateurDetails.getPassword());
            utilisateur.setActive(utilisateurDetails.isActive());
            utilisateur.setRoles(utilisateurDetails.getRoles());
            utilisateur.setUpdatedAt(new java.util.Date());
            return utilisateurR.save(utilisateur);
        });
    }

    // ✅ Supprimer un utilisateur
    public boolean deleteUtilisateur(Long id) {
        if (!utilisateurR.existsById(id)) {
            return false;
        }
        utilisateurR.deleteById(id);
        return true;
    }

    // ✅ Chercher par email (utile pour authentification ou vérification)
    public Optional<Utilisateur> findByEmail(String email) {
        return utilisateurR.findByEmail(email);
    }

    // ✅ Vérifier unicité username
    public boolean existsByUsername(String username) {
        return utilisateurR.existsByUsername(username);
    }

    // ✅ Vérifier unicité email
    public boolean existsByEmail(String email) {
        return utilisateurR.existsByEmail(email);
    }
}
