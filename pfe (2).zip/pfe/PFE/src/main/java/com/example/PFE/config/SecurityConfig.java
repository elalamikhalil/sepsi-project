package com.example.PFE.config;

import com.example.PFE.service.AuthService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    private final AuthService authService;

    public SecurityConfig(AuthService authService) {
        this.authService = authService;
    }

    // Crée un bean pour l'encodeur de mot de passe
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // Crée un bean pour l'AuthenticationManager
    @Bean
    public AuthenticationManager authManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authenticationManagerBuilder =
                http.getSharedObject(AuthenticationManagerBuilder.class);
        authenticationManagerBuilder.userDetailsService(authService)  // Utilise AuthService comme UserDetailsService
                .passwordEncoder(passwordEncoder());  // Utilisation de l'encodeur pour la gestion des mots de passe
        return authenticationManagerBuilder.build();
    }

    // Configure la sécurité des requêtes HTTP
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(authorize -> authorize
                        .requestMatchers("/api/auth/login").permitAll()  // Permet l'accès à la page de connexion sans authentification
                        .anyRequest().authenticated()  // Toute autre requête nécessite une authentification
                )
                .formLogin(form -> form  // Utilisation d'un formulaire personnalisé pour la page de connexion
                        .loginPage("/login")  // Personnalisation de l'URL pour la page de connexion
                        .permitAll()  // Permet à tout le monde d'accéder à la page de connexion
                )
                .csrf(csrf -> csrf.disable());  // Désactive la protection CSRF pour les API REST

        return http.build();
    }
}
