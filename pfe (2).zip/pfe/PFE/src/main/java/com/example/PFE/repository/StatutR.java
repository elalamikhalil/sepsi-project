package com.example.PFE.repository;

import com.example.PFE.model.Statut;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StatutR extends JpaRepository<Statut, Long> {

}
