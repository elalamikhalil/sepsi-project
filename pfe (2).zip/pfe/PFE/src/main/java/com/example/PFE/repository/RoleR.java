package com.example.PFE.repository;

import com.example.PFE.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RoleR extends JpaRepository<Role, Long> {
    // Méthode pour trouver un rôle par son nom
    Role findByName(String name);
}
