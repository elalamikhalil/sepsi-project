package com.example.PFE.controller;
import com.example.PFE.model.Statut;
import com.example.PFE.service.StatutS;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/statuts")
public class StatutC {

    @Autowired
    private StatutS statutService;

    // Créer un statut
    @PostMapping
    public ResponseEntity<Statut> createStatut(@RequestBody Statut statut) {
        Statut createdStatut = statutService.createStatut(statut);
        return new ResponseEntity<>(createdStatut, HttpStatus.CREATED);
    }

    // Mettre à jour un statut
    @PutMapping("/{id}")
    public ResponseEntity<Statut> updateStatut(@PathVariable Long id, @RequestBody Statut statutDetails) {
        Statut updatedStatut = statutService.updateStatut(id, statutDetails);
        if (updatedStatut != null) {
            return new ResponseEntity<>(updatedStatut, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Récupérer tous les statuts
    @GetMapping
    public List<Statut> getAllStatuts() {
        return statutService.getAllStatuts();
    }

    // Récupérer un statut par ID
    @GetMapping("/{id}")
    public ResponseEntity<Statut> getStatutById(@PathVariable Long id) {
        Statut statut = statutService.getStatutById(id);
        if (statut != null) {
            return new ResponseEntity<>(statut, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Supprimer un statut
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStatut(@PathVariable Long id) {
        boolean isDeleted = statutService.deleteStatut(id);
        if (isDeleted) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
