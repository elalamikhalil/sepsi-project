package com.example.PFE.service;

import com.example.PFE.model.Role;
import com.example.PFE.repository.RoleR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoleS {

    @Autowired
    private RoleR roleRepository;

    // Récupérer tous les rôles
    public List<Role> getAllRoles() {
        return roleRepository.findAll();
    }

    // Récupérer un rôle par ID
    public Optional<Role> getRoleById(Long id) {
        return roleRepository.findById(id);
    }

    // Créer un nouveau rôle
    public Role createRole(Role role) {
        role.setId(null); // sécurité : s'assurer qu'il s'agit d'un nouvel enregistrement
        return roleRepository.save(role);
    }

    // Mettre à jour un rôle
    public Optional<Role> updateRole(Long id, Role roleDetails) {
        return roleRepository.findById(id).map(role -> {
            role.setName(roleDetails.getName());
            role.setUpdatedAt(new java.util.Date());
            return roleRepository.save(role);
        });
    }

    // Supprimer un rôle
    public boolean deleteRole(Long id) {
        if (!roleRepository.existsById(id)) {
            return false;
        }
        roleRepository.deleteById(id);
        return true;
    }

    // Trouver un rôle par son nom
    public Role findByName(String name) {
        return roleRepository.findByName(name);
    }
}
