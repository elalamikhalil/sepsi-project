package com.example.PFE.controller;

import com.example.PFE.model.Utilisateur;
import com.example.PFE.repository.UtilisateurR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/utilisateurs")
@CrossOrigin(origins = "*") // pour accepter les requêtes front-end (Angular, React...)
public class UtilisateurC {

    @Autowired
    private UtilisateurR utilisateurRepository;

    // ✅ Récupérer tous les utilisateurs
    @GetMapping
    public List<Utilisateur> getAllUtilisateurs() {
        return utilisateurRepository.findAll();
    }

    // ✅ Récupérer un utilisateur par ID
    @GetMapping("/{id}")
    public ResponseEntity<Utilisateur> getUtilisateurById(@PathVariable Long id) {
        Optional<Utilisateur> utilisateur = utilisateurRepository.findById(id);
        return utilisateur.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // ✅ Créer un nouvel utilisateur
    @PostMapping
    public ResponseEntity<Utilisateur> createUtilisateur(@RequestBody Utilisateur utilisateur) {
        utilisateur.setId(null); // sécurité : éviter l'overwrite
        Utilisateur savedUser = utilisateurRepository.save(utilisateur);
        return ResponseEntity.ok(savedUser);
    }

    // ✅ Mettre à jour un utilisateur existant
    @PutMapping("/{id}")
    public ResponseEntity<Utilisateur> updateUtilisateur(@PathVariable Long id,
                                                         @RequestBody Utilisateur utilisateurDetails) {
        return utilisateurRepository.findById(id)
                .map(utilisateur -> {
                    utilisateur.setUsername(utilisateurDetails.getUsername());
                    utilisateur.setEmail(utilisateurDetails.getEmail());
                    utilisateur.setNom(utilisateurDetails.getNom());
                    utilisateur.setPrenom(utilisateurDetails.getPrenom());
                    utilisateur.setPassword(utilisateurDetails.getPassword()); // à sécuriser plus tard
                    utilisateur.setActive(utilisateurDetails.isActive());
                    utilisateur.setRoles(utilisateurDetails.getRoles());
                    utilisateur.setUpdatedAt(new java.util.Date());
                    return ResponseEntity.ok(utilisateurRepository.save(utilisateur));
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // ✅ Supprimer un utilisateur par ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUtilisateur(@PathVariable Long id) {
        if (!utilisateurRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        utilisateurRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
